# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]
     
        "*** YOUR CODE HERE ***"
      #  print("successorGameState: ",successorGameState)
      #  print("newPos: ",newPos)
      #  print("newFood: ",newFood)
      #  print("newGhostStates: ",newGhostStates)
      #  print("newScaredTimes: ",newScaredTimes)

        newfoodlist = newFood.asList()
        newghostpos = successorGameState.getGhostPositions()
        food=currentGameState.getFood()
        closestFood = float("inf") #we set the closest food a very large value
        closestGhost= float("inf") #we set the closest ghost a very large value	
        score=0
        #Data about food
        #Food with smallest distance from pacman

        for food in newfoodlist:
           closestFood = min([closestFood, manhattanDistance(newPos,food)])

        foodscore=1/closestFood
    
 
        #Data about ghosts
        #Ghost with smallest distance from pacman
        for ghost in newghostpos:
           closestGhost = min([closestGhost, manhattanDistance(newPos,ghost)])
           if manhattanDistance(newPos,ghost)<=1:  #if ghost too close,return very big number
              return float("-inf")
        
        ghostscore=1/closestGhost

        return successorGameState.getScore() + foodscore - ghostscore

def scoreEvaluationFunction(currentGameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """


    def testTerm (self, gameState, depth, agentIndex):
   
        # Initializations

        LegalActions = gameState.getLegalActions(agentIndex)
        numLegalActions = len(LegalActions)
        # Check whether the tree is done, whether there are legal actions, and whether it is an end state
        if ( (depth == self.depth) or (numLegalActions == 0) or gameState.isWin() or gameState.isLose() ):
            return True
        else: 
            return False


    def minValue (self, gameState, depth, agentIndex):
        """ 
        Minimizer for ghost agents 
        """
   
        # Initializations
        v = float("inf")
        numAgents = gameState.getNumAgents()   
        ghostLegalActions = gameState.getLegalActions(agentIndex)
        numLegalActions = len(ghostLegalActions)

        check=self.testTerm(gameState, depth, agentIndex)
        if check==True:
           return self.evaluationFunction(gameState)

        # Check if there is only one ghost remaining
        if (agentIndex == numAgents - 1): 
            v = min([self.maxValue(gameState.generateSuccessor(agentIndex, action), depth + 1) for action in ghostLegalActions])
        else: 
            v = min([self.minValue(gameState.generateSuccessor(agentIndex, action), depth, agentIndex + 1) for action in ghostLegalActions])
            
        return v

    def maxValue (self, gameState, depth):
        """ 
        Maximizer for pacman agent
        """
        
        # Initializations
        v = float("-inf")
        pacmanLegalActions = gameState.getLegalActions(0)
        numLegalActions = len(pacmanLegalActions)

        # Check whether the tree is done, whether there are legal actions, and whether it is an end state
        check=self.testTerm(gameState, depth, 0)
        if check==True:
           return self.evaluationFunction(gameState)
        else: 
            v = max([self.minValue(gameState.generateSuccessor(0, action), depth, 1) for action in pacmanLegalActions])
        
        return v 


    def getAction(self, gameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        "*** YOUR CODE HERE ***"

        # Initializations
        pacmanLegalActions = gameState.getLegalActions(0) 
        v = float("-inf")
        bestAction  = Directions.STOP 
        # we go through legal actions
        for action in pacmanLegalActions:
            successor = gameState.generateSuccessor(0, action) 
            score = self.minValue(successor, 0, 1)
            if (score > v): 
                v = score
                bestAction = action

        return bestAction 

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """
    #almost same as above
    def testTerm (self, gameState, depth, agentIndex):
   
        # Initializations

        LegalActions = gameState.getLegalActions(agentIndex)
        numLegalActions = len(LegalActions)
        # Check whether the tree is done, whether there are legal actions, and whether it is an end state
        if ( (depth == self.depth) or (numLegalActions == 0) or gameState.isWin() or gameState.isLose() ):
            return True
        else: 
            return False


    def minValue (self, gameState, depth, agentIndex, alpha, beta):
        """ 
        Minimizer for ghost agents 
        """

        # Initializations
        v = float("inf")
        numAgents = gameState.getNumAgents()
        ghostLegalActions = gameState.getLegalActions(agentIndex)      
        numLegalActions = len(ghostLegalActions)
 
        # Check whether the tree is done, whether there are legal actions, and whether it is an end state
        check=self.testTerm(gameState, depth, 0)
        if check==True:
           return self.evaluationFunction(gameState)
        
        for action in gameState.getLegalActions(agentIndex):
            if (agentIndex == numAgents - 1):
                v = min(v, self.maxValue(gameState.generateSuccessor(agentIndex,action), depth + 1, alpha, beta))
            else:  
                v = min(v, self.minValue(gameState.generateSuccessor(agentIndex, action), depth, agentIndex + 1, alpha, beta))

            if v < alpha:    #here we check current state with alpha beta
                return v
            beta = min(beta, v)

        return v

    def maxValue (self, gameState, depth, alpha, beta):
        """ 
        Maximizer for pacman agent
        """

        # Initializations
        v = float("-inf")
        pacmanLegalActions = gameState.getLegalActions(0)
        numLegalActions = len(pacmanLegalActions)

        # Check whether the tree is done, whether there are legal actions, and whether it is an end state
        check=self.testTerm(gameState, depth, 0)
        if check==True:
           return self.evaluationFunction(gameState)

        for action in pacmanLegalActions:
            v = max(v, self.minValue(gameState.generateSuccessor(0, action), 1, depth, alpha, beta))

            if v > beta:       #here we check current state with alpha beta
                return v
            alpha = max(alpha, v)

        return v

    def getAction(self, gameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"

        # Initializations 
        pacmanLegalActions = gameState.getLegalActions(0)
        v = float("-inf")
        alpha = float("-inf")
        beta = float("inf")
        bestAction = Directions.STOP 

        for action in pacmanLegalActions:
            successor = gameState.generateSuccessor(0, action)
            v = self.minValue(successor, 0, 1, alpha, beta)
            if v > alpha:
                alpha = v
                bestAction = action

        return bestAction


class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """
 
    def testTerm (self, gameState, depth, agentIndex):
   
        # Initializations

        LegalActions = gameState.getLegalActions(agentIndex)
        numLegalActions = len(LegalActions)
        # Check whether the tree is done, whether there are legal actions, and whether it is an end state
        if ( (depth == self.depth) or (numLegalActions == 0) or gameState.isWin() or gameState.isLose() ):
            return True
        else: 
            return False



    def minValue (self, gameState, depth, agentIndex):
        """ 
        Minimizer for ghost agents 
        """

        # Initializations
        v = 0
        numAgents = gameState.getNumAgents()
        ghostLegalActions = gameState.getLegalActions(agentIndex)
        numLegalActions = len(ghostLegalActions)

        check=self.testTerm(gameState, depth, 0)
        if check==True:
           return self.evaluationFunction(gameState)
        #for ghosts 
        for action in ghostLegalActions:
            if (agentIndex == numAgents - 1):
                v += self.maxValue(gameState.generateSuccessor(agentIndex,action), depth + 1 ) 
            else: 
                v += self.minValue(gameState.generateSuccessor(agentIndex, action), depth, agentIndex + 1) 

        return v/float(numLegalActions) # Divide by float since python division will round the result 
 
    def maxValue (self, gameState, depth):
        """ 
        Maximizer for pacman agent
        """

        # Initializations
        v = float("-inf")
        pacmanLegalActions = gameState.getLegalActions(0)
        numLegalActions = len(pacmanLegalActions)

         # Check whether the tree is done, whether there are legal actions, and whether it is an end state
        check=self.testTerm(gameState, depth, 0)
        if check==True:
           return self.evaluationFunction(gameState)

        for action in pacmanLegalActions:
            v = max(v, self.minValue(gameState.generateSuccessor(0, action), depth, 1) )

        return v


    def getAction(self, gameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"
        
         # Initializations 
        pacmanLegalActions = gameState.getLegalActions(0)
        v = float("-inf")
        bestAction = Directions.STOP

        for action in pacmanLegalActions:
            successor = gameState.generateSuccessor(0, action)
            score = self.minValue(successor, 0, 1)
            if score > v:
                v = score
                bestAction = action

        return bestAction
        util.raiseNotDefined()

def betterEvaluationFunction(currentGameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    # Useful information you can extract from a GameState (pacman.py)
    newPos = currentGameState.getPacmanPosition()
    newFood = currentGameState.getFood()
    newGhostStates = currentGameState.getGhostStates()
    newfoodlist = newFood.asList()
    newghostpos = currentGameState.getGhostPositions()
    closestFood = float("inf") #we set the closest food a very large value
    closestGhost= float("inf") #we set the closest ghost a very large value	
    food=currentGameState.getFood()
	
    score=0
    #Data about food


    for food in newfoodlist:
        closestFood = min([closestFood, manhattanDistance(newPos,food)])

    foodscore=1/closestFood
    
 
    #Data about ghosts
    for ghost in newghostpos:
        closestGhost = min([closestGhost, manhattanDistance(newPos,ghost)])
        if manhattanDistance(newPos,ghost)<=1:
           return float("-inf")
        

    ghostscore=1/closestGhost
    # we also need capsules
    newCapsule=currentGameState.getCapsules()
    numberofcapsules=len(newCapsule)

    return currentGameState.getScore() + foodscore - ghostscore -numberofcapsules

 
   

# Abbreviation
better = betterEvaluationFunction
